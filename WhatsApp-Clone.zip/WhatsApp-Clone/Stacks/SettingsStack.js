import React from 'react';
import {createStackNavigator,HeaderBackButton} from '@react-navigation/stack';
import {TouchableWithoutFeedback,Text,Alert} from 'react-native'


import Settings from '../Screens/Settings';
import Profile from '../Screens/Profile';
import About from '../Screens/About';
import StarMes from '../Screens/StarMes';
import Web from '../Screens/Web';


  
const stack = createStackNavigator();

export default function SettingsStack ({navigation}){
     return(
         <stack.Navigator initialRouteName='Settings' headerMode='screen'>
             <stack.Screen name='Settings' component={Settings} options={{headerTitleAlign:'Center',headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitle:'Settings',headerTitleStyle:{fontSize:23}}}/>
             <stack.Screen name='Profile' component={Profile} options={{headerTitleAlign:'Center',headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitle:'Edit Profile',headerTitleStyle:{fontSize:23}}}/>
             <stack.Screen name='About' component={About} options={{headerTitleAlign:'Center',headerRight:()=>{return(<TouchableWithoutFeedback><Text style={{color:'#1582DB',fontSize:19,paddingRight:18}}>Edit</Text></TouchableWithoutFeedback>)},headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitle:'About',headerTitleStyle:{fontSize:23}}}/>
             <stack.Screen name='StarMes' component={StarMes} options={{headerTitleAlign:'Center',headerRight:()=>{return(<TouchableWithoutFeedback><Text style={{color:'#1582DB',fontSize:19,paddingRight:18}}>Edit</Text></TouchableWithoutFeedback>)},headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitle:'Starred Messages',headerTitleStyle:{fontSize:20}}}/>
             <stack.Screen name='Web' component={Web} options={{headerTitleAlign:'Center',headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitle:'Scan QR Code',headerTitleStyle:{fontSize:23}}}/>        
         </stack.Navigator>
     )
 }