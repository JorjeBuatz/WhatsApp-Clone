import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import Status from '../Screens/Status';
import {View,Text,TouchableWithoutFeedback} from 'react-native';
import Piccopy from '../Component/Piccopy';
import Pt from '../Screens/Pt';
  
const stack = createStackNavigator();

export default function StatusStack (){
     return(
         <stack.Navigator  headerMode='screen' >
             <stack.Screen name='Status' component={Status} 
             options={{headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitleAlign:'Center',headerTitle:' ',headerLeft:()=>{return(<TouchableWithoutFeedback><Text style={{color:'#1582DB',fontSize:23,marginLeft:15}}>Privacy</Text></TouchableWithoutFeedback>)},headerTitleStyle:{fontSize:23}}}/>
             <stack.Screen name='Piccopy' component={Piccopy} 
             options={{headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitleAlign:'Center',headerTitle:' ',headerTitleStyle:{fontSize:23}}}/>
             <stack.Screen name='Pt' component={Pt} headerMode='none'
             options={{headerStyle:{backgroundColor:'white',borderBottomColor:'white',height:50},headerTitleAlign:'Center',headerTitle:' '}}/>
         </stack.Navigator>
     )
 }