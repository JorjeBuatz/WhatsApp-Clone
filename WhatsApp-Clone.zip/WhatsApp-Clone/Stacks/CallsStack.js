import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import Status from '../Screens/Status';
import {View,Text,TouchableWithoutFeedback} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

import Calls from '../Screens/Calls';
  
const stack = createStackNavigator();

export default function CallsStack (){
     return(
         <stack.Navigator initialRouteName='Calls' headerMode='screen'>
             <stack.Screen name='Call' component={Calls} 
             options={{headerTitleAlign:'Center',headerTitle:'Calls',headerLeft:()=>{return(<TouchableWithoutFeedback><Text style={{color:'#1582DB',fontSize:23,marginLeft:15}}>Edit</Text></TouchableWithoutFeedback>)}, headerRight:()=>{return(<TouchableWithoutFeedback><View style={{marginRight:15,flexDirection:'row'}}><Ionicons name='ios-call' size={28} color='#1582DB' /></View></TouchableWithoutFeedback>)},headerTitleStyle:{fontSize:23}}}/>
         </stack.Navigator>
     )
 }