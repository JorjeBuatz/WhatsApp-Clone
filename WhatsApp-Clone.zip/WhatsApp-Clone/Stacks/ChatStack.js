import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import Status from '../Screens/Status';
import {View,Text,TouchableWithoutFeedback} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import Chats from '../Screens/Chats';
import Lchat from '../Screens/Lchat';

  
const stack = createStackNavigator();

export default function CallsStack (){
     return(
         <stack.Navigator initialRouteName='Chats'headerMode='screen' >
             <stack.Screen name='Chat' component={Chats} 
             options={{headerTitleAlign:'Center',headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitle:'Calls',headerLeft:()=>{return(<TouchableWithoutFeedback><Text style={{color:'#1582DB',fontSize:23,marginLeft:15}}>Edit</Text></TouchableWithoutFeedback>)}, headerRight:()=>{return(<TouchableWithoutFeedback><View style={{marginRight:15,flexDirection:'row'}}><Ionicons name='ios-create' size={28} color='#1582DB' /></View></TouchableWithoutFeedback>)},headerTitleStyle:{fontSize:23}}}/>
             <stack.Screen name='Lchat' component={Lchat} 
             options={{headerTitleAlign:'Center',headerStyle:{backgroundColor:'#F2F2F1',borderBottomColor:'#ADADAD',borderBottomWidth:0.3},headerTitle:'Linda', headerRight:()=>{return(<TouchableWithoutFeedback><View style={{marginRight:15,flexDirection:'row'}}><Ionicons name='ios-create' size={28} color='#1582DB' /></View></TouchableWithoutFeedback>)},headerTitleStyle:{fontSize:23}}}/>
         </stack.Navigator>
     )
 }