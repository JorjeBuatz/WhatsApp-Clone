import React, { useState, useEffect } from 'react';
import { Text, View, TouchableOpacity } from 'react-native';
import { Camera } from 'expo-camera';
import {Ionicons} from '@expo/vector-icons';

export default function CameraScreen() {
  const [hasPermission, setHasPermission] = useState(null);
  const [type, setType] = useState(Camera.Constants.Type.back);

  useEffect(() => {
    (async () => {
      const { status } = await Camera.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  if (hasPermission === null) {
    return <View />;
  }
  if (hasPermission === false) {
    return <Text>No access to camera</Text>;
  }
  return (
    <View style={{ flex: 1 }}>
      <Camera style={{ flex: 1 }} type={type}>
          
          
           
        <View style={{marginTop:510,flexDirection:'row'}}>
          <TouchableOpacity><View style={{marginLeft:20,marginTop:30}}><Ionicons name='ios-image' size={40} color='white' /></View></TouchableOpacity>
          <TouchableOpacity><View style={{marginLeft:100}} ><Ionicons name='md-radio-button-off' size={80} color='white' /></View></TouchableOpacity>
        <View
          style={{marginLeft:100,
            marginTop:30,
            backgroundColor: 'transparent',
            flexDirection: 'row',
          }}>

          <TouchableOpacity
            style={{
              
              
              
            }}
            onPress={() => {
              setType(
                type === Camera.Constants.Type.back
                  ? Camera.Constants.Type.front
                  : Camera.Constants.Type.back
              );
            }}>
            <Ionicons name='ios-camera' color='white' size={50} />
          </TouchableOpacity>
          
        </View>
        </View>
        <View style={{alignItems:'center'}}><Text style={{color:'white'}}> Hold for vidoe, tap for photo</Text></View>

        
      </Camera>
    </View>
  );
}