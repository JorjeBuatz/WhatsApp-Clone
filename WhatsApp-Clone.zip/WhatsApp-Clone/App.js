import React from 'react';
import { Dimensions,ScrollView, Text, View } from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import Navigator from './Route/Navigator';
import Main from './Route/Main'

export default function App() {
  return (
    <NavigationContainer>
        <Main />
    </NavigationContainer>
  );
}


