import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {View,Text,TouchableWithoutFeedback} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

import First from '../Screens/First';
import Second from '../Screens/Second';
import Third from '../Screens/Third';
import Fourth from '../Screens/Fourth';
import MainNavigator from './Navigator'
  
const stack = createStackNavigator();

export default function CallsStack (){
     return(
         <stack.Navigator initialRouteName='Calls' headerMode='none'>
             <stack.Screen name='First' component={First} options={{headerTitle:' ',headerStyle:{backgroundColor:'white' }  }} />
             <stack.Screen name='Second' component={Second} options={{headerTitle:' ',headerStyle:{backgroundColor:'white' }}} />
             <stack.Screen name='Third' component={Third} options={{headerTitle:' '}} />
             <stack.Screen name='Fourth' component={Fourth} options={{headerTitle:' '}} />
             <stack.Screen name='Main' component={MainNavigator} options={{headerTitle:''}} />

         </stack.Navigator>
     )
 }