import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {Ionicons} from '@expo/vector-icons';

import StatusStack from '../Stacks/StatusStack';
import SettingsStack from '../Stacks/SettingsStack';
import CallsStack from '../Stacks/CallsStack';
import Photo from '../Screens/Photo';
import ChatStack from '../Stacks/ChatStack';


const Tab = createBottomTabNavigator();

const Navigator = () =>{
    return(
        <Tab.Navigator initialRouteName='Chat' tabBarOptions={{inactiveTintColor:'#949494',labelStyle:{fontSize:13},activeTintColor:'#0E7CD0'}} >
            <Tab.Screen name='Status' component={StatusStack} options={{tabBarLabel: 'Status',tabBarIcon: ({color}) =>  <Ionicons  name='md-radio-button-off' color={color} size={28} /> }} />
            <Tab.Screen name='Calls' component={CallsStack} options={{tabBarLabel: 'Calls',tabBarIcon: ({color}) =>  <Ionicons  name="ios-call" color={color} size={28} /> }} />
            <Tab.Screen name='Camera' component={Photo} options={{tabBarLabel: 'Camera',tabBarIcon: ({color}) =>  <Ionicons  name="ios-camera" color={color} size={28} /> }}  />
            <Tab.Screen name='Chat' component={ChatStack} options={{tabBarLabel: 'Chats',tabBarIcon: ({color}) =>  <Ionicons  name="ios-chatbubbles" color={color} size={28} /> }} />
            <Tab.Screen name='Settings' component={SettingsStack} options={{tabBarLabel: 'Settings',tabBarIcon: ({color}) =>  <Ionicons  name="ios-cog" color={color} size={28} /> }} />
        </Tab.Navigator>
    )
}
 export default Navigator;