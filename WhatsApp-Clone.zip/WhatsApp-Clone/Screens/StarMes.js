import React from 'react';
import {View,Image,Text,ScrollView,TouchableOpacity} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function StarMes() {
    return (
        <ScrollView style={{backgroundColor:'#EFEFEF'}}>
            <View style={{flex:1}}>
                {/** 1st */}
                <TouchableOpacity>
                <View>
                    <View style={{flexDirection:'row',paddingHorizontal:12,marginTop:5,alignItems:'center'}}>
                        <Image style={{height:30,width:30,borderRadius:20}} source={{uri:'https://i.pravatar.cc/400?img=58'}} />
                        <View style={{flexDirection:'row',justifyContent:'space-between',flex:1}}>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'#3C3D3D' }}> Patrick </Text>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'grey' }}> 10:32 AM </Text>
                        </View>     
                    </View>

                    <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',flexDirection:'row',height:30,alignItems:'center',marginTop:10,paddingHorizontal:10,width:254,marginLeft:45}}>
                        <Text>Are you done with the project?</Text>
                        <View style={{flexDirection:'row',marginTop:13}}>
                            <Ionicons style={{marginLeft:8}} name='ios-star' size={10} color='grey' />
                            <Text style={{fontSize:10,color:'grey'}}> 10:32 AM </Text>
                        </View>
                    <View style={{marginLeft:50}}>
                        <Ionicons name='ios-arrow-forward' color='grey' size={20} /> 
                    </View>
                    </View>
                    <View style={{borderBottomWidth:0.3,borderBottomColor:'grey',marginLeft:45,marginTop:15}}></View>
                    
                </View>
                </TouchableOpacity>

                {/** 2nd */}
                <TouchableOpacity>
                <View>
                    <View style={{flexDirection:'row',paddingHorizontal:12,marginTop:5,alignItems:'center'}}>
                        <Image style={{height:30,width:30,borderRadius:20}} source={{uri:'https://i.pravatar.cc/400?img=37'}} />
                        <View style={{flexDirection:'row',justifyContent:'space-between',flex:1}}>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'#3C3D3D' }}> Linda </Text>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'grey' }}> 7:00 AM </Text>
                        </View>     
                    </View>

                    <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',flexDirection:'row',height:30,alignItems:'center',marginTop:10,paddingHorizontal:10,width:190,marginLeft:45}}>
                        <Text> Ok see you later... </Text>
                        <View style={{flexDirection:'row',marginTop:13}}>
                            <Ionicons style={{marginLeft:8}} name='ios-star' size={10} color='grey' />
                            <Text style={{fontSize:10,color:'grey'}}> 7:00 AM </Text>
                        </View>
                    <View style={{marginLeft:115}}>
                        <Ionicons name='ios-arrow-forward' color='grey' size={20} /> 
                    </View>
                    </View>
                    <View style={{borderBottomWidth:0.5,borderBottomColor:'grey',marginLeft:45,marginTop:15}}></View>
                    
                </View>
                </TouchableOpacity>

                {/** 3rd */}
                <TouchableOpacity>
                <View>
                    <View style={{flexDirection:'row',paddingHorizontal:12,marginTop:5,alignItems:'center'}}>
                        <Image style={{height:30,width:30,borderRadius:20}} source={{uri:'https://i.pravatar.cc/400?img=28'}} />
                        <View style={{flexDirection:'row',justifyContent:'space-between',flex:1}}>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'#3C3D3D' }}> Sandra </Text>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'grey' }}> 5:32 PM </Text>
                        </View>     
                    </View>

                    <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',flexDirection:'row',height:30,alignItems:'center',marginTop:10,paddingHorizontal:10,width:254,marginLeft:45}}>
                        <Text>What is the name of the place?</Text>
                        <View style={{flexDirection:'row',marginTop:13}}>
                            <Ionicons style={{marginLeft:8}} name='ios-star' size={10} color='grey' />
                            <Text style={{fontSize:10,color:'grey'}}> 5:32 PM </Text>
                        </View>
                    <View style={{marginLeft:50}}>
                        <Ionicons name='ios-arrow-forward' color='grey' size={20} /> 
                    </View>
                    </View>
                    <View style={{borderBottomWidth:0.5,borderBottomColor:'grey',marginLeft:45,marginTop:15}}></View>
                    
                </View>
                </TouchableOpacity>

                {/** 4th */}
                <TouchableOpacity>
                <View>
                    <View style={{flexDirection:'row',paddingHorizontal:12,marginTop:5,alignItems:'center'}}>
                        <Image style={{height:30,width:30,borderRadius:20}} source={{uri:'https://i.pravatar.cc/400?img=12'}} />
                        <View style={{flexDirection:'row',justifyContent:'space-between',flex:1}}>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'#3C3D3D' }}> Franks </Text>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'grey' }}> 10:32 AM </Text>
                        </View>     
                    </View>

                    <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',flexDirection:'row',height:30,alignItems:'center',marginTop:10,paddingHorizontal:10,width:254,marginLeft:45}}>
                        <Text>Are you ok with the new place?</Text>
                        <View style={{flexDirection:'row',marginTop:13}}>
                            <Ionicons style={{marginLeft:8}} name='ios-star' size={10} color='grey' />
                            <Text style={{fontSize:10,color:'grey'}}> 10:32 AM </Text>
                        </View>
                    <View style={{marginLeft:46}}>
                        <Ionicons name='ios-arrow-forward' color='grey' size={20} /> 
                    </View>
                    </View>
                    <View style={{borderBottomWidth:0.5,borderBottomColor:'grey',marginLeft:45,marginTop:15}}></View>
                    
                </View>
                </TouchableOpacity>

                {/** 5th */}
                <TouchableOpacity>
                <View>
                    <View style={{flexDirection:'row',paddingHorizontal:12,marginTop:5,alignItems:'center'}}>
                        <Image style={{height:30,width:30,borderRadius:20}} source={{uri:'https://i.pravatar.cc/400?img=9'}} />
                        <View style={{flexDirection:'row',justifyContent:'space-between',flex:1}}>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'#3C3D3D' }}> Cindy </Text>
                            <Text style={{marginLeft:5,fontWeight:'600',color:'grey' }}> 6:22 AM </Text>
                        </View>     
                    </View>

                    <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',flexDirection:'row',height:30,alignItems:'center',marginTop:10,paddingHorizontal:10,width:275,marginLeft:45}}>
                        <Text>It has been so long, where are you?</Text>
                        <View style={{flexDirection:'row',marginTop:13}}>
                            <Ionicons style={{marginLeft:8}} name='ios-star' size={10} color='grey' />
                            <Text style={{fontSize:10,color:'grey'}}> 6:22 AM </Text>
                        </View>
                    <View style={{marginLeft:20}}>
                        <Ionicons name='ios-arrow-forward' color='grey' size={20} /> 
                    </View>
                    </View>
                    <View style={{borderBottomWidth:0.5,borderBottomColor:'grey',marginLeft:45,marginTop:15}}></View>
                    
                </View>
                </TouchableOpacity>
                

           
           </View>
        </ScrollView>
        
    )
}
