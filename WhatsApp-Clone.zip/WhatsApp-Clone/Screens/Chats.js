import React from 'react';
import {View,Text,ScrollView,TouchableOpacity,Image} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

function Chats( {navigation}) {
    return (
        <ScrollView style={{flex:1}} >
        <View style={{flex:1}}>
        <TouchableOpacity onPress={()=> navigation.navigate('Lchat')}>
                <View style={{flexDirection:'row',height:80}}>
                    <View style={{paddingLeft:15,marginTop:20}}>
                        <Image style={{height:40,width:40,borderRadius:30}} source={{uri:'https://i.pravatar.cc/400?img=37'}} />
                    </View>
                    <View style={{flexDirection:'row' ,marginLeft:17,borderBottomColor:'grey',borderBottomWidth:0.3,flex:1,justifyContent:'space-between',alignItems:'center',paddingRight:15}}>
                        <View style={{marginTop:2}}>
                            <Text style={{fontSize:19,fontWeight:'500'}}>Linda</Text>
                            <View style={{flexDirection:'row', alignItems:'center'}}>
                                <Ionicons name='ios-checkmark' size={28} color='grey' />
                                <Text style={{color:'grey',fontSize:16,paddingLeft:7}}>Im here</Text>
                            </View>
                        </View>
                        <View style={{alignItems:'center'}} >
                            <Text style={{color:'grey'}}>6:02 PM</Text>
                            <View style={{marginTop:5,height:20,width:20,borderRadius:30,backgroundColor:'#1582DB',justifyContent:'center',alignItems:'center'}}>
                                <Text style={{color:'white'}}>1</Text>
                            </View>
                        </View>
                    </View>
                </View>
                </TouchableOpacity>


        </View>
        </ScrollView>
    )
}

export default Chats
