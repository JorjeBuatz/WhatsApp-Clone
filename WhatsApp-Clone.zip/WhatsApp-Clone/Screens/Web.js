import React from 'react';
import {View,Text} from 'react-native';
import CameraScreen from '../Component/Camera';


export default function Web() {
    return (
        <View style={{flex:1}}>
            <View style={{height:80,backgroundColor:'#BABABA',justifyContent:'center',alignItems:'center'}}>
                <Text style={{fontSize:20,color:'grey'}}> To use WhatsApp Web,go to</Text>
                <Text style={{fontSize:20,color:'grey'}} > web.WhatsApp.com on your computer. </Text>
            </View>
            <View style={{height:360}} >
                 <CameraScreen />
            </View>
        </View>
    )
}
