import React from 'react';
import {View,Text,ImageBackground, ImageBackgroundBase} from 'react-native';

export default function Pt({navigation}) {
    return (
        <View style={{flex:1}}>
             <ImageBackground style={{height:'100%',width:'100%'}} source={{uri:'https://i.pravatar.cc/400?img=2'}} >

             </ImageBackground>
        </View>
    )
}
