import React,{useState} from 'react';
import {View,Text,Image,TouchableOpacity,TextInput,TouchableWithoutFeedback,Keyboard} from 'react-native';
import {Ionicons} from '@expo/vector-icons';


export default function Profile({navigation}) {
    const [userName,setUserName] = useState('')

    const getName = (word)=>{
        let name = word;
        setUserName(name)
    } 
    return (
        <TouchableWithoutFeedback onPress={()=> Keyboard.dismiss()}>
        <View style={{flex:1,backgroundColor:'#F2F2F1'}}>
            {/** 1st */}
            <View style={{height:157,backgroundColor:'white',borderBottomWidth:0.3,borderBottomColor:'#BDBBBB'}}>
                <View style={{flexDirection:'row',alignItems:'center'}} >
                    <TouchableWithoutFeedback>
                        <View style={{alignItems:'center',paddingHorizontal:15,marginTop:10}}>
                            <Image style={{height:60,width:60,borderRadius:40}} source={{uri:'https://i.pravatar.cc/400?img=62'}} /> 
                            <Text style={{color:'#1582DB',fontSize:18,marginTop:5}}>Edit</Text>
                        </View>
                    </TouchableWithoutFeedback>
                    <View style={{marginLeft:10,marginBottom:20}}>
                        <Text style={{color:'grey'}}>Enter your name and an optional</Text>
                        <Text style={{color:'grey'}} >profile picture</Text>
                    </View>
                </View>

                <View style={{height:37,borderBottomColor:'#BDBBBB',marginLeft:15,borderBottomWidth:0.3,borderTopWidth:0.3,borderTopColor:'#BDBBBb',marginTop:14}}>
                    <TextInput onChangeText={getName} style={{height:38,fontSize:20}} placeholder= 'Name' />
                    
                </View>
        </View>

        {/** 2nd */}
        <View>
            <View style={{marginTop:30,backgroundColor:'#F2F2F1',marginLeft:15}}>
                <Text style={{color:'grey'}}>PHONE NUMBER</Text>
            </View>
            <View style={{justifyContent:'center',backgroundColor:'white',height:40,marginTop:5,borderTopWidth:0.3,borderTopColor:'#BDBBBB',borderBottomColor:'#BDBBBB',borderBottomWidth:0.3}}>
                <Text style={{marginLeft:15,fontSize:18}}>+233 540580872 </Text>
            </View>
        </View>

        {/** 3rd */}
        <View>
            <View style={{marginTop:30,backgroundColor:'#F2F2F1',marginLeft:15}}>
                <Text style={{color:'grey'}}>ABOUT</Text>
            </View>
            <TouchableOpacity onPress={()=>{navigation.navigate('About')}} >
            <View style={{alignItems:'center',flexDirection:'row',backgroundColor:'white',justifyContent:'space-between',paddingHorizontal:15,height:40,marginTop:5,borderTopWidth:0.3,borderTopColor:'#BDBBBB',borderBottomColor:'#BDBBBB',borderBottomWidth:0.3}}>
                <View >
                    <Text style={{fontSize:18}}> Hard work pays </Text></View>
                    <Ionicons name='ios-arrow-forward' size={17} color='grey' />
                </View>
            </TouchableOpacity>
        </View>
        

            


        </View>
        </TouchableWithoutFeedback>
    )
}
