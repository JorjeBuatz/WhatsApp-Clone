import React from 'react';
import {View,Text,Image,Button} from 'react-native';

export default function First({navigation}) {
    return (
        <View style={{flex:1,backgroundColor:'white'}}>
            <View style={{alignItems:'center'}}>
                <Text style={{fontSize:30,color:'#1BA2A0'}}> Welcome to WhatsApp</Text>                
            </View>
            <View style={{alignItems:'center'}}>
                <Image style={{marginTop:80,height:300,width:300,borderRadius:50}} source={require('../Images/Im.png')} />
            </View>
            <View style={{marginTop:60,paddingHorizontal:10}}>
                <Text style={{color:'grey'}} >Tap "Agree and Continue" to accept the <Text style={{color:'#1582DB'}} > WhatsApp Terms of</Text> </Text>
                 <Text style={{color:'#1582DB'}} >Service and Privacy Policy</Text> 
            </View>
            <View style={{marginTop:40,paddingHorizontal:15}}>
                <Button style={{height:20,width:250}} title='Angree and Continue' onPress={()=> navigation.navigate('Second')} />
            </View>
        </View>
    )
}
