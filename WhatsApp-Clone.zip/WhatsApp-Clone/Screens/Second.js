import React,{useState} from 'react';
import {View,Text,TouchableOpacity,Alert,Button,TextInput,TouchableWithoutFeedback,Keyboard} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function Second({navigation}) {
    const [number,setNumber] =  useState('');
    const [name,setName] =  useState('');

    const getName =(nm)=>{
        setName(nm)
    }

    const getNumber =(num)=>{
        setNumber(num)
    }
    const submit = () =>{
        if (number =='' || name ==''){
             Alert.alert('Fill all the fields')
        }
        else{
            Alert.alert(number,'Is this OK, would you like to edit your number',[{text:'Edit'},{text:'Proceed',onPress:()=>{navigation.navigate('Third', {nam: name, num: number}  )}     }])
            
        }
        
    }
    return (
        <TouchableWithoutFeedback onPress={()=> Keyboard.dismiss()}>
        <View style={{flex:1,backgroundColor:'white'}}>
            <View style={{height:80,flexDirection:'row'}}>
                <View style={{marginLeft:50,justifyContent:'center'}} ><Text style={{color:'#1BA2A0',fontSize:25}}>Verify your phone number</Text></View>
              <TouchableOpacity style={{marginLeft:45,marginTop:6,justifyContent:'center'}} ><View ><Ionicons name='md-more' size={30} color='black'  /></View></TouchableOpacity> 
            </View>

            <View style={{marginTop:30,paddingLeft:8,justifyContent:'center',alignItems:'center'}}>
                <Text style={{fontSize:17}}>WhatsApp will send an sms message to verify for</Text>
                <Text style={{fontSize:18}}>phone number. Enter your countery code and </Text>
                <Text style={{fontSize:18}}>phone code and phone number </Text>
            </View>

            <View style={{height:50,marginTop:30,borderBottomWidth:0.3,borderBottomColor:'grey',justifyContent:'flex-end'}}>
                <TextInput onChangeText={getName} style={{marginLeft:40 ,height:50,fontSize:20,width:300}} textAlign='center' placeholder='Country' />
            </View>
            <View style={{height:50,marginTop:30,borderBottomWidth:0.3,borderBottomColor:'grey',justifyContent:'flex-end'}}>
                <TextInput keyboardType='number-pad' onChangeText={getNumber}style={{marginLeft:40 ,height:50,fontSize:20,width:300}} textAlign='center' placeholder='Number' />
            </View>

            <View style={{justifyContent:'center',alignItems:'center',marginTop:40}}>
              <View style={{height:30,width:90}}><Button onPress={submit } title='NEXT' /></View>

                <Text style={{marginTop:40,color:'grey'}}> Carrier SMS charges may apply </Text>
            </View>
            
        </View>
        </TouchableWithoutFeedback>
    )
}
