import React,{useState} from 'react';
import {View,Text,KeyboardAvoidingView,Platform,ImageBackground,Dimensions,ScrollView,TextInput,TouchableOpacity} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function Lchat() {
    const ScreenWidth = Dimensions.get('window').width;
    const ScreenHeight = Dimensions.get('window').height;

    const [chat,setChat] = useState([])

    return (
       <View style={{flex:1,justifyContent:'space-between'}}>
           <ImageBackground style={{height:510,width:ScreenWidth}} source={{uri:'https://images-na.ssl-images-amazon.com/images/I/71qHpgdzk3L._SX466_.jpg'}}>
           <KeyboardAvoidingView behavior={Platform.OS == "ios" ? "padding" : "height"} style={{flex:1}} >
                <ScrollView>
                    <View style={{alignItems:'center'}}>
                        <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',height:20,alignItems:'center',justifyContent:'center',marginTop:10,paddingHorizontal:10,width:80,marginLeft:45}}>
                            <Text style={{fontSize:15}}>Friday</Text>                         
                        </View>
                    </View>

                    <View>
                        <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',flexDirection:'row',height:30,alignItems:'center',marginTop:10,paddingHorizontal:10,width:170,marginLeft:15}}>
                            <Text>Ok see you later...</Text>
                            <View style={{flexDirection:'row',marginTop:13}}>                              
                                <Text style={{marginLeft:8,fontSize:10,color:'grey'}}> 5:32 PM </Text>
                            </View>
                        
                        </View>
                    </View>

                    {/** chat */}

                    <View>
                        <View style={{borderTopLeftRadius:10,borderBottomRightRadius:10,borderTopRightRadius:10,borderBottomLeftRadius:10,backgroundColor:'white',flexDirection:'row',height:30,alignItems:'center',marginTop:10,paddingHorizontal:10,width:170,marginLeft:195}}>
                            <Text>Ok see you later...</Text>
                            <View style={{flexDirection:'row',marginTop:13}}>                              
                                <Text style={{marginLeft:8,fontSize:10,color:'grey'}}> 5:32 PM </Text>
                            </View>
                        
                        </View>
                    </View>


                </ScrollView>
                </KeyboardAvoidingView>
                
           </ImageBackground>

            <View style={{flex:1,paddingHorizontal:15,backgroundColor:'white',alignItems:'center',flexDirection:'row',borderTopColor:'grey',borderTopWidth:0.3}}>
                <TouchableOpacity><Ionicons name='ios-add' size={35} color='#1582DB' /></TouchableOpacity>
                <View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',borderWidth:0.3,borderColor:'grey',marginLeft:7,height:35,width:230,backgroundColor:'white',borderTopLeftRadius:20,borderBottomLeftRadius:20,borderTopRightRadius:20,borderBottomRightRadius:20}}>
                <TextInput style={{height:35,width:200,paddingHorizontal:10,fontSize:20,maxHeight:100}} multiline  />
                <TouchableOpacity><Ionicons style={{marginRight:7}} name='ios-add' size={35} color='#1582DB' /></TouchableOpacity>
                </View>

                <View style={{flexDirection:'row'}}>
               <TouchableOpacity><Ionicons style={{marginLeft:15}} name='ios-camera' size={27} color='#1582DB' /></TouchableOpacity> 
                <TouchableOpacity><Ionicons style={{marginLeft:27}} name='ios-camera' size={27} color='#1582DB' /></TouchableOpacity>
                </View>

            </View>
       </View> 
    )
}
