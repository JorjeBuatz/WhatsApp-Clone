import React,{useState} from 'react';
import {View,Text,Image,Button,Modal,ScrollView,TouchableOpacity,Alert} from 'react-native';
import {Ionicons} from '@expo/vector-icons';


export default function Status({navigation}) {
    const [isStatus, setIsStatus] = useState(false);
    const [isModal,setIsModal] = useState(false);

    
    return (
        <ScrollView>
        <View style={{flex:1,backgroundColor:'#EFEFEF'}}>


            <TouchableOpacity onPress={()=> navigation.navigate('Piccopy')}>
            <View style={{backgroundColor:'white',height:80,borderBottomWidth:0.5,borderBottomColor:'#848484',borderTopWidth:0.3,borderTopColor:'#848484'}}>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                    <View style={{paddingLeft:15,paddingTop:10}}>
                        <Image style={{height:60,width:60,borderRadius:40}} source={{uri:'https://i.pravatar.cc/400?img=62'}} />
                    </View>
                    <View style={{flexDirection:'row',flex:1,alignItems:'center',paddingRight:15,justifyContent:'space-between'}}>
                        <View style={{paddingLeft:15}}>
                            <Text style={{fontSize:19,fontWeight:'600',marginTop:6}}> My Status</Text>
                            <Text style={{fontSize:14,color:'grey',marginTop:3}}> Add to my status</Text>
                        </View>
                    
                        <View style={{flexDirection:'row'}}>
                            <TouchableOpacity >
                            <View style={{height:30,width:30,borderRadius:30,justifyContent:'center',alignItems:'center',backgroundColor:'#EFEFEF'}}>
                                <Ionicons name='ios-camera' color='#1582DB' size={20} />
                            </View>
                            </TouchableOpacity>

                            <TouchableOpacity>
                            <View style={{marginLeft:20,height:30,width:30,borderRadius:30,justifyContent:'center',alignItems:'center',backgroundColor:'#EFEFEF'}}>
                                <Ionicons name='md-create' color='#1582DB' size={20} />
                            </View>
                            </TouchableOpacity>

                        </View>
                    </View>
                </View>

            </View>
            </TouchableOpacity>

            <View style={{marginTop:45,paddingLeft:15}}>
                <Text style={{color:'grey',paddingBottom:10}} >RECENT UPDATES</Text>
            </View>
            <TouchableOpacity onPress={()=> navigation.navigate('Pt')} >
            <View style={{backgroundColor:'white',height:80,borderBottomWidth:0.5,borderBottomColor:'#848484',borderTopWidth:0.3,borderTopColor:'#848484'}}>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                    <View style={{paddingLeft:15,paddingTop:10}}>
                        <Image style={{height:60,width:60,borderRadius:40}} source={{uri:'https://i.pravatar.cc/400?img=2'}} />
                    </View>
                    <View style={{flexDirection:'row',flex:1,alignItems:'center',paddingRight:15,justifyContent:'space-between'}}>
                        <View style={{paddingLeft:15}}>
                            <Text style={{fontSize:19,fontWeight:'600',marginTop:6}}> Patrick</Text>
                            <Text style={{fontSize:14,color:'grey',marginTop:3}}> 3m ago </Text>
                        </View>
                    
                    </View>
                </View>

            </View>
            </TouchableOpacity>

            


        </View>

        
        </ScrollView>
    )
}
