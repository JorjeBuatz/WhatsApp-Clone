import React from 'react';
import {View,Text,TouchableOpacity,TextInput,Button,TouchableWithoutFeedback,Keyboard} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function Fourth({navigation}) {
    return (
        <TouchableWithoutFeedback onPress={()=> Keyboard.dismiss()}>
        <View style={{flex:1}}>
            <View style={{marginTop:40,justifyContent:'center',alignItems:'center'}}>
                <Text style={{fontSize:30,color:'#0D9263'}}> Profile info </Text>
                    <Text style={{fontSize:20,color:'grey',marginTop:30}}>Please provide your name and an optional</Text>
                    <Text style={{fontSize:20,color:'grey'}}>photo</Text>
                </View>
        
        <View style={{marginTop:20,flexDirection:'row',height:100,paddingHorizontal:18,alignItems:'center'}}>
        <TouchableOpacity>
            <View style={{height:70,width:70,borderRadius:60,backgroundColor:'#C6C6C6',justifyContent:'center',alignItems:'center'}}>
              <Ionicons name='ios-camera' size={40} color='#E8E8E8' /> 
            </View>
            </TouchableOpacity> 

            <View style={{width:180,justifyContent:'center',alignItems:'center',marginLeft:30,orderBottomColor:'#043121',borderBottomWidth:3}}>
                <TextInput style={{height:30,marginBottom:3,fontSize:25}} placeholder='Name' textAlign='center' keyboardType='number-pad' />
            </View>

            <TouchableWithoutFeedback>
            <View style={{marginLeft:20,marginTop:15}}>
                <Ionicons name='ios-happy' size={30} color='grey' />
            </View>
            </TouchableWithoutFeedback>

        </View>


        <View><Button title='NEXT' onPress={()=>{navigation.navigate('Main')}} /></View>
            
        </View>
        </TouchableWithoutFeedback>
    )
}
