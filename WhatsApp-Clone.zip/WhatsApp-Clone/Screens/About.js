import React,{useState} from 'react';
import {View,Text,ScrollView,Button,TouchableOpacity,Modal,TextInput} from 'react-native';
import {Ionicons} from '@expo/vector-icons'

export default function About() {
    const [isModal,setIsModal] = useState(false);
    const [update,setUpdate] = useState('');
    const [aboutList,setAboutList] = useState([{key: Math.random().toString() ,val:'Available'},{key: Math.random().toString() ,val:'Busy'},{key: Math.random().toString() ,val:'At school'},{key: Math.random().toString() ,val:'At the movies'},{key: Math.random().toString() ,val:'Battery about to die'},{key: Math.random().toString() ,val:"Can't talk "},{key: Math.random().toString() ,val:'WhatsApp only'},{key: Math.random().toString() ,val:'In a meeting'},{key: Math.random().toString() ,val:'At the gym'},{key: Math.random().toString() ,val:'Sleeping'},{key: Math.random().toString() ,val:'Urgent calls only'}]);

    const getUpdate = (word)=>{
        setUpdate(word);
    }

     function saveAbout(){
         setAboutList(prev=>[ {key: Math.random().toString(),val:update}, ...aboutList]);
         setIsModal(false)
         
     }
    return (
        <View style={{flex:1,backgroundColor:'#F2F2F1'}}>
            <ScrollView>
                    <View>
                        <View style={{marginTop:30,backgroundColor:'#F2F2F1',marginLeft:15}}>
                            <Text style={{color:'grey'}}>ABOUT</Text>
                        </View>
                        
                        <Modal visible={isModal} animated='slide' >
                            <View style={{flex:1,backgroundColor:'#F2F2F1'}} >
                                <View style={{flexDirection:'row',backgroundColor:'white',marginTop:7,borderBottomColor:'#BDBBBB',alignItems:'center',borderBottomWidth:0.3,height:70}}>
                                    <View style={{marginLeft:15,height:30,width:70}}><Button onPress={()=>{setIsModal(false)}} title='Cancel' /></View>
                                    <View style={{marginLeft:77}}><Text style={{fontSize:23,fontWeight:'700'}}>About</Text></View>
                                    <View style={{marginLeft:55,height:30,width:70}}><Button onPress={saveAbout} title='Save' /></View>
                                </View>
                                <View style={{backgroundColor:'white',marginTop:20,flex:1}}>
                                    <TextInput onChangeText={getUpdate} style={{marginHorizontal:15,fontSize:18,height:542}} multiline />
                                </View>
                            </View>
                        </Modal>
                        

                        <TouchableOpacity onPress={()=>{setIsModal(true)}} >
                            <View style={{alignItems:'center',flexDirection:'row',backgroundColor:'white',justifyContent:'space-between',paddingHorizontal:15,height:40,marginTop:5,borderTopWidth:0.3,borderTopColor:'#BDBBBB',borderBottomColor:'#BDBBBB',borderBottomWidth:0.3}}>
                                <View >
                                    <Text style={{fontSize:18}}> {update} </Text></View>
                                    <Ionicons name='ios-arrow-forward' size={17} color='grey' />
                            </View>
                        </TouchableOpacity>
                    </View>

                    <View>                        
                            <View style={{marginTop:30,backgroundColor:'#F2F2F1'}}>
                                <Text style={{color:'grey',marginLeft:15}}>SELECT YOUR ABOUT</Text>
                                <View style={{marginTop:5,borderBottomColor:'#BDBBBB',borderBottomWidth:0.3}}></View>

                                <View style={{backgroundColor:'white'}}>
                                    {aboutList.map((stat)=>
                                    <TouchableOpacity>
                                        <View style={{borderBottomWidth:0.3,height:50,justifyContent:'center',borderBottomColor:'#BDBBBB'}}>
                                        <Text key={(stat)=>stat.key} style={{fontSize:18,marginLeft:15}}>{stat.val}</Text>
                                        </View>
                                    </TouchableOpacity>
                                    )}
                                </View>
                            </View>
                        
                </View>
            </ScrollView>
            
        </View>
        
    )
}

{/**


<View style={{borderColor:'black',borderWidth:1}} >
                                <FlatList keyExtractor={(item, indexed)=> item.key} data={aboutList} renderItem={(itemData)=> <Text>{itemData.item.val}</Text> } />
                            </View>
*/}