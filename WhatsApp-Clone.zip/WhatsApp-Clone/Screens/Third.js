import React from 'react';
import {View,Text,TextInput,TouchableOpacity,Button,TouchableWithoutFeedback,Keyboard} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function Third({navigation, route}) {
    return (
        <TouchableWithoutFeedback onPress={()=>Keyboard.dismiss()}>
        <View style={{flex:1}}>
            <View style={{height:80,flexDirection:'row'}}>
                <View style={{marginLeft:50,justifyContent:'center'}} ><Text style={{color:'#1BA2A0',fontSize:25}}>Verify {route.params.num && <Text> {route.params.num} </Text> } </Text></View>
              <TouchableOpacity style={{marginLeft:45,marginTop:6,justifyContent:'center'}} ><View style={{marginLeft:39}} ><Ionicons name='md-more' size={30} color='black'  /></View></TouchableOpacity> 
            </View>

            <View style={{paddingHorizontal:10,marginTop:20,justifyContent:'center',alignItems:'center'}}>
                <Text style={{fontSize:20}}>Waiting for verification code to be sent to</Text>
                <View style={{flexDirection:'row',alignItems:'center'}}>
                    {route.params.num && <Text style={{fontSize:21,marginTop:4}}> {route.params.num} </Text> }
                    <Text style={{fontSize:18,marginTop:10,color:'#3FBBE1'}}>Wrong Number?</Text>
                </View>
                
            </View>

            <View style={{marginHorizontal:120,justifyContent:'center',alignItems:'center',marginTop:60,orderBottomColor:'#043121',borderBottomWidth:3}}>
                <TextInput style={{height:30,marginBottom:10,fontSize:30}} placeholder='--- ---' textAlign='center' keyboardType='number-pad' />
            </View>
            <View style={{justifyContent:'center',alignItems:'center',marginTop:10}}>
                <Text style={{color:'grey'}}> Enter 6-digit code</Text>
            </View>

            <View style={{marginTop:40}}>
            <TouchableOpacity>
                <View style={{borderBottomWidth:0.3,paddingHorizontal:20,borderBottomColor:'grey',flexDirection:'row'}}>
                <Ionicons name='ios-call' size={24} color='grey'  />
                    <Text style={{color:'grey',marginLeft:10,fontSize:20}}>Resend SMS</Text> 
                </View>
            </TouchableOpacity>
            <TouchableOpacity>
                <View style={{borderBottomWidth:0.3,paddingHorizontal:20,marginTop:30,borderBottomColor:'grey',flexDirection:'row'}}>
                    <Ionicons name='ios-call' size={24} color='grey'  />
                    <Text style={{color:'grey',marginLeft:10,fontSize:20 }} >Call Me</Text> 
                </View>
            </TouchableOpacity>

            </View>

            <View style={{justifyContent:'center',alignItems:'center',marginTop:30}}>
                <Button title='Verify' onPress={()=>{navigation.navigate('Fourth')}} />
            </View>



            
            
        </View>
        </TouchableWithoutFeedback>
    )
}
