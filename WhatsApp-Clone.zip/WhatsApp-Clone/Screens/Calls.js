import React from 'react';
import {View,Text,Image,ScrollView,TouchableOpacity} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function Calls() {
    return (
        <ScrollView>
            <View style={{flex:1}}>

                {/** 1 */}
                <TouchableOpacity>
                <View style={{flexDirection:'row',height:50}}>
                    <View style={{paddingLeft:15,marginTop:5}}>
                        <Image style={{height:40,width:40,borderRadius:30}} source={{uri:'https://i.pravatar.cc/400?img=58'}} />
                    </View>
                    <View style={{flexDirection:'row' ,paddingBottom:5,borderBottomColor:'grey',borderBottomWidth:0.3,flex:1,justifyContent:'space-between',alignItems:'center',paddingRight:15}}>
                        <View style={{marginTop:5,paddingLeft:12}}>
                            <Text style={{fontSize:19,fontWeight:'500'}}>Patrick</Text>
                            <View style={{flexDirection:'row'}}>
                                <Ionicons name='ios-videocam' size={17} color='grey' />
                                <Text style={{color:'grey',fontSize:16,paddingLeft:7}}>Outgoing</Text>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={{color:'grey'}}>2:34 PM</Text>
                            <Ionicons style={{paddingLeft:10}} name='ios-information-circle-outline' size={20} color='#1582DB' />
                        </View>
                    </View>
                </View>
                </TouchableOpacity>

                {/** 2 */}
                <TouchableOpacity>
                <View style={{flexDirection:'row',height:50}}>
                    <View style={{paddingLeft:15,marginTop:5}}>
                        <Image style={{height:40,width:40,borderRadius:30}} source={{uri:'https://i.pravatar.cc/400?img=37'}} />
                    </View>
                    <View style={{flexDirection:'row' ,paddingBottom:5,borderBottomColor:'grey',borderBottomWidth:0.3,flex:1,justifyContent:'space-between',alignItems:'center',paddingRight:15}}>
                        <View style={{marginTop:5,paddingLeft:12}}>
                            <Text style={{fontSize:19,fontWeight:'500'}}>Linda</Text>
                            <View style={{flexDirection:'row'}}>
                                <Ionicons name='ios-videocam' size={17} color='grey' />
                                <Text style={{color:'grey',fontSize:16,paddingLeft:7}}>Incoming</Text>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={{color:'grey'}}>6:02 PM</Text>
                            <Ionicons style={{paddingLeft:10}} name='ios-information-circle-outline' size={20} color='#1582DB' />
                        </View>
                    </View>
                </View>
                </TouchableOpacity>

                 {/** 3 */}
                 <TouchableOpacity>
                <View style={{flexDirection:'row',height:50}}>
                    <View style={{paddingLeft:15,marginTop:5}}>
                        <Image style={{height:40,width:40,borderRadius:30}} source={{uri:'https://i.pravatar.cc/400?img=28'}} />
                    </View>
                    <View style={{flexDirection:'row' ,paddingBottom:5,borderBottomColor:'grey',borderBottomWidth:0.3,flex:1,justifyContent:'space-between',alignItems:'center',paddingRight:15}}>
                        <View style={{marginTop:5,paddingLeft:12}}>
                            <Text style={{fontSize:19,fontWeight:'500'}}>Sandra</Text>
                            <View style={{flexDirection:'row'}}>
                                <Ionicons name='ios-videocam' size={17} color='grey' />
                                <Text style={{color:'grey',fontSize:16,paddingLeft:7}}>Incoming</Text>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={{color:'grey'}}>10:34 AM</Text>
                            <Ionicons style={{paddingLeft:10}} name='ios-information-circle-outline' size={20} color='#1582DB' />
                        </View>
                    </View>
                </View>
                </TouchableOpacity>

                 {/** 4 */}
                 <TouchableOpacity>
                <View style={{flexDirection:'row',height:50}}>
                    <View style={{paddingLeft:15,marginTop:5}}>
                        <Image style={{height:40,width:40,borderRadius:30}} source={{uri:'https://i.pravatar.cc/400?img=58'}} />
                    </View>
                    <View style={{flexDirection:'row' ,paddingBottom:5,borderBottomColor:'grey',borderBottomWidth:0.3,flex:1,justifyContent:'space-between',alignItems:'center',paddingRight:15}}>
                        <View style={{marginTop:5,paddingLeft:12}}>
                            <Text style={{fontSize:19,fontWeight:'500'}}>Patrick</Text>
                            <View style={{flexDirection:'row'}}>
                                <Ionicons name='ios-videocam' size={17} color='grey' />
                                <Text style={{color:'grey',fontSize:16,paddingLeft:7}}>Outgoing</Text>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={{color:'grey'}}>7:01 PM</Text>
                            <Ionicons style={{paddingLeft:10}} name='ios-information-circle-outline' size={20} color='#1582DB' />
                        </View>
                    </View>
                </View>
                </TouchableOpacity>

                 {/** 5 */}
                 <TouchableOpacity>
                <View style={{flexDirection:'row',height:50}}>
                    <View style={{paddingLeft:15,marginTop:5}}>
                        <Image style={{height:40,width:40,borderRadius:30}} source={{uri:'https://i.pravatar.cc/400?img=58'}} />
                    </View>
                    <View style={{flexDirection:'row' ,paddingBottom:5,borderBottomColor:'grey',borderBottomWidth:0.3,flex:1,justifyContent:'space-between',alignItems:'center',paddingRight:15}}>
                        <View style={{marginTop:5,paddingLeft:12}}>
                            <Text style={{fontSize:19,fontWeight:'500'}}>Patrick</Text>
                            <View style={{flexDirection:'row'}}>
                                <Ionicons name='ios-videocam' size={17} color='grey' />
                                <Text style={{color:'grey',fontSize:16,paddingLeft:7}}>Incoming</Text>
                            </View>
                        </View>
                        <View style={{flexDirection:'row'}}>
                            <Text style={{color:'grey'}}>9:15 PM</Text>
                            <Ionicons style={{paddingLeft:10}} name='ios-information-circle-outline' size={20} color='#1582DB' />
                        </View>
                    </View>
                </View>
                </TouchableOpacity>


            </View>
        </ScrollView>
    )
}
