import React from 'react';
import {View,Text,Image,TouchableOpacity,ScrollView} from 'react-native';
import {Ionicons} from '@expo/vector-icons';

export default function Settings({navigation}) {
    return (
        <ScrollView>
        <View style={{flex:1,backgroundColor:'#F2F2F1'}}>
            <TouchableOpacity onPress={()=> navigation.navigate('Profile')}>
                <View style={{height:70,flexDirection:'row',backgroundColor:'white',borderBottomColor:'#BDBBBB',borderBottomWidth:0.3,paddingHorizontal:15,alignItems:'center'}}>
                    <View>
                        <Image style={{height:55,width:55,borderRadius:40}} source={{uri:'https://i.pravatar.cc/400?img=62'}} />
                    </View>
                    <View style={{justifyContent:'space-between',flexDirection:'row',flex:1,alignItems:'center'}}>
                        <View style={{marginLeft:15}}>
                            <Text style={{fontSize:25,fontWeight:'500'}}>Khalebb</Text>
                            <Text style={{fontSize:16,color:'grey'}} >Hard work pays</Text>
                        </View>
                        <View>
                            <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                        </View>
                    </View>
                </View>
            </TouchableOpacity>


            {/** 1st */}

            <View style={{marginTop:35}} >    
             <View style={{height:90,paddingVertical:6,backgroundColor:'white',borderColor:'#BDBBBB',borderWidth:0.3,paddingLeft:15}}>
                   <TouchableOpacity onPress={()=> navigation.navigate('StarMes')}>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={require('../Images/Star.png')} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,borderBottomWidth:0.3,paddingVertical:10,borderBottomColor:'#BDBBBB'}}>
                                <Text style={{fontSize:18}} >Starred Messages</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>    
                        </View>
                    </TouchableOpacity>


                    <TouchableOpacity onPress={()=> navigation.navigate('Web')}>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={require('../Images/Laptop.png')} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,paddingVertical:10}}>
                                <Text style={{fontSize:18}}>WhatsApp Web/Desktop</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>   
                            
                        </View>  
                    </TouchableOpacity>  

                </View>
            </View>

            
                {/** 2nd */}

           
            <View style={{marginTop:35}} >    
             <View style={{height:195,paddingVertical:8,backgroundColor:'white',borderColor:'#BDBBBB',borderWidth:0.3,paddingLeft:15}}>
                   <TouchableOpacity>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={{uri:'https://wallpapercave.com/wp/wp3851781.jpg'}} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,borderBottomWidth:0.3,paddingVertical:13,borderBottomColor:'#BDBBBB'}}>
                                <Text style={{fontSize:18}} >Account</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>    
                        </View>
                    </TouchableOpacity>


                    <TouchableOpacity>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={{uri:'https://wallpapercave.com/wp/wp3851781.jpg'}} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,paddingVertical:13,borderBottomColor:'#BDBBBB',borderBottomWidth:0.3}}>
                                <Text style={{fontSize:18}}>Chats</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>   
                            
                        </View>  
                    </TouchableOpacity>  


                    <TouchableOpacity>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={{uri:'https://wallpapercave.com/wp/wp3851781.jpg'}} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,borderBottomWidth:0.3,paddingVertical:13,borderBottomColor:'#BDBBBB'}}>
                                <Text style={{fontSize:18}} >Notifications</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>    
                        </View>
                    </TouchableOpacity>


                    <TouchableOpacity>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={{uri:'https://wallpapercave.com/wp/wp3851781.jpg'}} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,paddingVertical:13}}>
                                <Text style={{fontSize:18}} >Data and Storage Usage</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>    
                        </View>
                    </TouchableOpacity>

                </View>
            </View>


            {/** 3rd */}

            <View style={{marginTop:35}} >    
             <View style={{height:85,paddingVertical:5,backgroundColor:'white',borderColor:'#BDBBBB',borderWidth:0.3,paddingLeft:15}}>
                   <TouchableOpacity>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={{uri:'https://wallpapercave.com/wp/wp3851781.jpg'}} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,borderBottomWidth:0.3,paddingVertical:10,borderBottomColor:'#BDBBBB'}}>
                                <Text style={{fontSize:18}} >Help</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>    
                        </View>
                    </TouchableOpacity>


                    <TouchableOpacity>
                        <View style={{flexDirection:'row',alignItems:'center'}}>
                            <View>
                                <Image style={{height:30,width:30,borderRadius:7}} source={{uri:'https://wallpapercave.com/wp/wp3851781.jpg'}} />
                            </View>  
                            <View style={{flexDirection:'row',justifyContent:'space-between',flex:1,marginLeft:19,paddingVertical:10}}>
                                <Text style={{fontSize:18}}>Tell a Friend</Text>
                                <View style={{paddingRight:15}}>
                                    <Ionicons name='ios-arrow-forward' color='grey' size={17} />
                                </View>
                            </View>   
                            
                        </View>  
                    </TouchableOpacity>  

                </View>
            </View>

            <View style={{flex:1,alignItems:'center',marginVertical:35}}>
                <Text >from</Text>
                <Text style={{marginTop:5,fontSize:20,color:'#251B5C'}}>FACEBOOK</Text>
            </View>




        </View>
        </ScrollView>
    )
}