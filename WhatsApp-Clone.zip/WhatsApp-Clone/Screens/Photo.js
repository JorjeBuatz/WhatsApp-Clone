import React,{useState} from 'react';
import {View,Text,Modal,Button} from 'react-native';
import Pic from '../Component/Pic'

export default function Photo() {
    const [isModal,setIsModal] = useState(true)
    return (
        <View style={{flex:1}}>                  
            <View style={{flex:1}}>
                <Pic />
            </View>
          
        </View>
    )
}
